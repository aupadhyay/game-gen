tapToPlay_x = 160
tapToPlay_y = 240
tapToPlay_anchor_x = 0.5
tapToPlay_anchor_y = 0.5

background_x = 160
background_y = 240
background_anchor_x = 0.5
background_anchor_y = 0.5

player_x = 50
player_y = 240
player_anchor_x = 0.5
player_anchor_y = 0.5
player_width = 40
player_height = 40

pipesTop_x = 150 
pipesTop_y = 0
pipesTop_anchor_x = 1
pipesTop_anchor_y = 0
pipesTop_width = 60
pipesTop_height = 150

pipesBottom_x = 150
pipesBottom_y= 430
pipesBottom_anchor_x = 1
pipesBottom_anchor_y = 1
pipesTop_width = 60
pipesTop_height = 180


ground_x = 0
ground_y = 480
ground_anchor_x = 0
ground_anchor_y = 1
pipesTop_width = 320
pipesTop_height = 50