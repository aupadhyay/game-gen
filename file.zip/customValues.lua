scrollSpeed_int = 6
distanceBetweenPipes_x = 300  
firstIntervalPipeGap = 110
secondIntervalPipeGap = 145